# SpringBootProject
Simple spring boot Application.
