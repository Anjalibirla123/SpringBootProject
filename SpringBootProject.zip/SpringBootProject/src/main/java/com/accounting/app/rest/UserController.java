package com.accounting.app.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.accounting.app.dto.ResponseDto;
import com.accounting.app.service.UserService;
import com.accounting.app.exception.BadAPIResponseException;
import com.accounting.app.entity.User;

@RestController
@RequestMapping("/api/v1")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping(value = "/signup/app-user")
	public ResponseEntity<ResponseDto> saveUserDetails(@RequestBody User user) throws BadAPIResponseException {
		ResponseDto response = userService.signupUser(user);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@PutMapping(value = "/user/{userId}/update-user/user")
	public ResponseEntity<ResponseDto> editUserDetails(@RequestBody User user, @PathVariable Long userId) {
		ResponseDto response = userService.editUser(userId, user);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@DeleteMapping(value = "/user/{userId}/delete-user/user")
	public ResponseEntity<ResponseDto> softDeleteByUserId(@PathVariable Long userId) {
		ResponseDto response = new ResponseDto();
		try {
			response = userService.deleteByUserId(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
