package com.accounting.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaheshwariAccountingAndConsultancyApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MaheshwariAccountingAndConsultancyApplication.class, args);
	}

}
