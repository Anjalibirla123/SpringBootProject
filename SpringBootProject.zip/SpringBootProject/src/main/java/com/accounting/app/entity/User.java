package com.accounting.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.annotation.Generated;

@Entity
@Table(name = "User")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Long userId;

	@Column(name = "name")
	private String name;

	@Column(name = "phone_number")
	private String phoneNumber;

	@Column(name = "policy_number")
	private String policyNumber;

	@Column(name = "email", unique = true)
	private String emailId;

	@Column(name = "dateOfBirth")
	private String dateOfBirth;

	@Column(name = "gender")
	private String gender;

	@Column(name = "marital_status")
	private String maritalStatus;

	@Column(name = "requirements")
	private String requirements;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "password")
	private String password;

	@Generated("SparkTools")
	private User(Builder builder) {
		this.userId = builder.userId;
		this.name = builder.name;
		this.phoneNumber = builder.phoneNumber;
		this.policyNumber = builder.policyNumber;
		this.emailId = builder.emailId;
		this.dateOfBirth = builder.dateOfBirth;
		this.gender = builder.gender;
		this.maritalStatus = builder.maritalStatus;
		this.requirements = builder.requirements;
		this.createdDate = builder.createdDate;
		this.password = builder.password;
	}

	public User() {

	}

	public User(Long userId, String name, String phoneNumber, String policyNumber, String emailId, String dateOfBirth,
			String gender, String maritalStatus, String requirements, String createdDate, String password) {
		super();
		this.userId = userId;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.policyNumber = policyNumber;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.requirements = requirements;
		this.createdDate = createdDate;
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getRequirements() {
		return requirements;
	}

	public void setRequirements(String requirements) {
		this.requirements = requirements;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", phoneNumber=" + phoneNumber + ", policyNumber="
				+ policyNumber + ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender
				+ ", maritalStatus=" + maritalStatus + ", requirements=" + requirements + ", createdDate=" + createdDate
				+ "]";
	}

	@Generated("SparkTools")
	public static Builder builder() {
		return new Builder();
	}

	@Generated("SparkTools")
	public static final class Builder {
		private Long userId;
		private String name;
		private String phoneNumber;
		private String policyNumber;
		private String emailId;
		private String dateOfBirth;
		private String gender;
		private String maritalStatus;
		private String requirements;
		private String createdDate;
		private String password;

		private Builder() {
		}

		public Builder withUserId(Long userId) {
			this.userId = userId;
			return this;
		}

		public Builder withName(String name) {
			this.name = name;
			return this;
		}

		public Builder withPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
			return this;
		}

		public Builder withPolicyNumber(String policyNumber) {
			this.policyNumber = policyNumber;
			return this;
		}

		public Builder withEmailId(String emailId) {
			this.emailId = emailId;
			return this;
		}

		public Builder withDateOfBirth(String dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
			return this;
		}

		public Builder withGender(String gender) {
			this.gender = gender;
			return this;
		}

		public Builder withMaritalStatus(String maritalStatus) {
			this.maritalStatus = maritalStatus;
			return this;
		}

		public Builder withRequirements(String requirements) {
			this.requirements = requirements;
			return this;
		}

		public Builder withCreatedDate(String createdDate) {
			this.createdDate = createdDate;
			return this;
		}

		public Builder withPassword(String password) {
			this.password = password;
			return this;
		}

		public User build() {
			return new User(this);
		}
	}

}
