package com.accounting.app.service;

public class AuthenticationManager {

}
