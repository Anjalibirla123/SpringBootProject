package com.accounting.app.common;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;

import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.Generated;

public class Response<T> implements Serializable {
	
	private static final long serialVersionUID = -5808131840139943805L;
	
	@JsonIgnore
	private HttpHeaders headers;

	private String status;

	private transient T data;
	
	@JsonProperty(value = "erros")
	private transient Collection<?> errors = Collections.emptyList();

	@JsonProperty(value = "warnings")
	private transient Collection<?> warnings = Collections.emptyList();

	private Long timestamp;

	@Generated("SparkTools")
	private Response(Builder builder) {
		this.headers = builder.headers;
		this.status = builder.status;
		this.errors = builder.errors;
		this.warnings = builder.warnings;
		this.timestamp = builder.timestamp;
	}

	public Response() {
		super();
	}

	public Response(HttpHeaders headers, String status, T data, Collection<?> errors, Collection<?> warnings,
			Long timestamp) {
		super();
		this.headers = headers;
		this.status = status;
		this.data = data;
		this.errors = errors;
		this.warnings = warnings;
		this.timestamp = timestamp;
	}

	public HttpHeaders getHeaders() {
		return headers;
	}

	public void setHeaders(HttpHeaders headers) {
		this.headers = headers;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Collection<?> getErrors() {
		return errors;
	}

	public void setErrors(Collection<?> errors) {
		this.errors = errors;
	}

	public Collection<?> getWarnings() {
		return warnings;
	}

	public void setWarnings(Collection<?> warnings) {
		this.warnings = warnings;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "Response [headers=" + headers + ", status=" + status + ", timestamp=" + timestamp + "]";
	}

	@Generated("SparkTools")
	public static Builder builder() {
		return new Builder();
	}

	@Generated("SparkTools")
	public static final class Builder {
		private HttpHeaders headers;
		private String status;
		private Collection<?> errors = Collections.emptyList();
		private Collection<?> warnings = Collections.emptyList();
		private Long timestamp;

		private Builder() {
		}

		public Builder withHeaders(HttpHeaders headers) {
			this.headers = headers;
			return this;
		}

		public Builder withStatus(String status) {
			this.status = status;
			return this;
		}

		public Builder withErrors(Collection<?> errors) {
			this.errors = errors;
			return this;
		}

		public Builder withWarnings(Collection<?> warnings) {
			this.warnings = warnings;
			return this;
		}

		public Builder withTimestamp(Long timestamp) {
			this.timestamp = timestamp;
			return this;
		}

		public Response build() {
			return new Response(this);
		}
	}
	
	

}
