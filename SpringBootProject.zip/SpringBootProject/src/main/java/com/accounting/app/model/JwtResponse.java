package com.accounting.app.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import javax.annotation.Generated;

import com.accounting.app.dto.ResponseDto;

public class JwtResponse extends ResponseDto implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;

	private String jwttoken;

	private String username;
	
	private String email;

	private Long userId;

	private List<String> roles;

	private Long sessionTimeout;

	@Generated("SparkTools")
	private JwtResponse(Builder builder) {
		this.jwttoken = builder.jwttoken;
		this.username = builder.username;
		this.email = builder.email;
		this.userId = builder.userId;
		this.roles = builder.roles;
		this.sessionTimeout = builder.sessionTimeout;
	}

	public String getJwttoken() {
		return jwttoken;
	}

	public void setJwttoken(String jwttoken) {
		this.jwttoken = jwttoken;
	}

	public String getUsername() {
		return username;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public Long getSessionTimeout() {
		return sessionTimeout;
	}

	public void setSessionTimeout(Long sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	@Override
	public String toString() {
		return "JwtResponse [jwttoken=" + jwttoken + ", username=" + username + ", roles=" + roles + "]";
	}

	/**
	 * Creates builder to build {@link JwtResponse}.
	 * 
	 * @return created builder
	 */
	@Generated("SparkTools")
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Builder to build {@link JwtResponse}.
	 */
	@Generated("SparkTools")
	public static final class Builder extends ResponseDto.Builder {
		private String jwttoken;
		private String username;
		private String email;
		private Long userId;
		private List<String> roles = Collections.emptyList();
		private Long sessionTimeout;

		private Builder() {
		}

		public Builder withJwttoken(String jwttoken) {
			this.jwttoken = jwttoken;
			return this;
		}

		public Builder withUsername(String username) {
			this.username = username;
			return this;
		}
		
		public Builder withEmail(String email) {
			this.email = email;
			return this;
		}


		public Builder withUserId(Long userId) {
			this.userId = userId;
			return this;
		}

		public Builder withRoles(List<String> roles) {
			this.roles = roles;
			return this;
		}

		public Builder withSessionTimeout(Long sessionTimeout) {
			this.sessionTimeout = sessionTimeout;
			return this;
		}

		public JwtResponse build() {
			return new JwtResponse(this);
		}
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}