package com.accounting.app.enums;

import org.json.JSONException;
import org.json.JSONObject;

import com.accounting.app.common.Constants;

public enum ErrorConstants {
	USER_DELETED(1000,"User is Deleted"),
	INVALID_LOGIN_CRIDENTIALS(1001, "Please Enter valid username/password"),
	NO_USER_EXIST(1002, "Project does not exist");
	
	private final Integer errCode;
	private final String errDesc;

	private ErrorConstants(int errCode, String errDesc) {
		this.errCode = errCode;
		this.errDesc = errDesc;
	}

	public Integer getErrCode() {
		return errCode;
	}

	public String getErrDesc() {
		return errDesc;
	}

	public static String getAsJson(ErrorConstants constants) throws JSONException{

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("responseText", "Failure");
		jsonObject.put(Constants.ERROR_CODE, constants.getErrCode());
		jsonObject.put(Constants.ERROR_DESC, constants.getErrDesc());
		return jsonObject.toString();
	}
}