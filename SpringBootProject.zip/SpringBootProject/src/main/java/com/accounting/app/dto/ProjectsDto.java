package com.accounting.app.dto;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ProjectsDto extends ResponseDto {

	private Long id;

	private Long createdBy;

	private Long modifiedBy;

	@JsonInclude(Include.NON_DEFAULT)
	private Long roleId;

	@JsonInclude(Include.NON_DEFAULT)
	private Long projectUserId;

	@JsonInclude(Include.NON_NULL)
	private String role;

	private String projectName;

	private String accountName;

	private String cordinatorEmail;

	private String businessType;

	private String projectType;

	private String createdDate;

	private String modifiedDate;

	private Boolean status;

	private Integer projectHealth;

	private int modulesCount;

	@Generated("SparkTools")
	private ProjectsDto(Builder builder) {
		this.id = builder.id;
		this.projectName = builder.projectName;
		this.accountName = builder.accountName;
		this.projectHealth = builder.projectHealth;
		this.modulesCount = builder.modulesCount;
		this.cordinatorEmail = builder.cordinatorEmail;
		this.businessType = builder.businessType;
		this.projectType = builder.projectType;
		this.status = builder.status;
		this.createdDate = builder.createdDate;
		this.createdBy = builder.createdBy;
		this.modifiedDate = builder.modifiedDate;
		this.modifiedBy = builder.modifiedBy;
		this.role = builder.role;
		this.roleId = builder.roleId;
		this.projectUserId = builder.projectUserId;
	}

	public Long getProjectUserId() {
		return projectUserId;
	}

	public void setProjectUserId(Long projectUserId) {
		this.projectUserId = projectUserId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public ProjectsDto() {
		super();
	}

	public Long getId() {
		return id;
	}

	public String getProjectName() {
		return projectName;
	}

	public String getAccountName() {
		return accountName;
	}

	public Integer getProjectHealth() {
		return projectHealth;
	}

	public int getModulesCount() {
		return modulesCount;
	}

	public String getCordinatorEmail() {
		return cordinatorEmail;
	}

	public Boolean isStatus() {
		return status;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public void setProjectHealth(Integer projectHealth) {
		this.projectHealth = projectHealth;
	}

	public void setModulesCount(int modulesCount) {
		this.modulesCount = modulesCount;
	}

	public void setCordinatorEmail(String cordinatorEmail) {
		this.cordinatorEmail = cordinatorEmail;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	@Override
	public String toString() {
		return "ProjectsDto [id=" + id + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy + ", roleId="
				+ roleId + ", projectUserId=" + projectUserId + ", role=" + role + ", projectName=" + projectName
				+ ", accountName=" + accountName + ", cordinatorEmail=" + cordinatorEmail + ", businessType="
				+ businessType + ", projectType=" + projectType + ", createdDate=" + createdDate + ", modifiedDate="
				+ modifiedDate + ", status=" + status + ", projectHealth=" + projectHealth + ", modulesCount="
				+ modulesCount + "]";
	}

	/**
	 * Creates builder to build {@link ProjectsDto}.
	 * 
	 * @return created builder
	 */
	@Generated("SparkTools")
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Builder to build {@link ProjectsDto}.
	 */
	@Generated("SparkTools")
	public static final class Builder extends ResponseDto.Builder {
		private Long id;
		private String projectName;
		private String accountName;
		private Integer projectHealth;
		private int modulesCount;
		private String cordinatorEmail;
		private String businessType;
		private String projectType;
		private Boolean status;
		private String createdDate;
		private Long createdBy;
		private String modifiedDate;
		private Long modifiedBy;
		private String role;
		private Long roleId;
		private Long projectUserId;

		private Builder() {
		}

		public Builder withId(Long id) {
			this.id = id;
			return this;
		}

		public Builder withProjectName(String projectName) {
			this.projectName = projectName;
			return this;
		}

		public Builder withAccountName(String accountName) {
			this.accountName = accountName;
			return this;
		}

		public Builder withProjectHealth(Integer projectHealth) {
			this.projectHealth = projectHealth;
			return this;
		}

		public Builder withModulesCount(int modulesCount) {
			this.modulesCount = modulesCount;
			return this;
		}

		public Builder withCordinatorEmail(String cordinatorEmail) {
			this.cordinatorEmail = cordinatorEmail;
			return this;
		}

		public Builder withBusinessType(String businessType) {
			this.businessType = businessType;
			return this;
		}

		public Builder withProjectType(String projectType) {
			this.projectType = projectType;
			return this;
		}

		public Builder withStatus(Boolean status) {
			this.status = status;
			return this;
		}

		public Builder withCreatedDate(String createdDate) {
			this.createdDate = createdDate;
			return this;
		}

		public Builder withCreatedBy(Long createdBy) {
			this.createdBy = createdBy;
			return this;
		}

		public Builder withModifiedDate(String modifiedDate) {
			this.modifiedDate = modifiedDate;
			return this;
		}

		public Builder withModifiedBy(Long modifiedBy) {
			this.modifiedBy = modifiedBy;
			return this;
		}

		public Builder withRole(String role) {
			this.role = role;
			return this;
		}

		public Builder withRoleId(Long roleId) {
			this.roleId = roleId;
			return this;
		}

		public Builder withProjectUserId(Long projectUserId) {
			this.projectUserId = projectUserId;
			return this;
		}

		public ProjectsDto build() {
			return new ProjectsDto(this);
		}
	}
}