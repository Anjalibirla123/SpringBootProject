package com.accounting.app.rest;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.authentication.AuthenticationManager;
import com.accounting.app.enums.ErrorConstants;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.accounting.app.exception.BadAPIResponseException;
import com.accounting.app.model.JwtRequest;
import com.accounting.app.model.JwtResponse;
import com.accounting.app.service.AuditLogService;
import com.accounting.app.service.JwtTokenUtil;
import com.accounting.app.service.JwtUserDetailsService;



@RestController
@CrossOrigin
@RequestMapping("/api/v1")
public class JwtAuthenticationController {
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsService userDetailsService;

	@Autowired
	private AuditLogService auditLogService;

	@Value("${jwt.expire.time}")
	private Long sessionTimeout;

	


	
	private void authenticate(String username, String password) throws BadAPIResponseException , JSONException {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause().getMessage().toString().contains("User is Deleted")) {
				throw new BadAPIResponseException(ErrorConstants.USER_DELETED, null);
			} else {
				throw new BadAPIResponseException(ErrorConstants.INVALID_LOGIN_CRIDENTIALS, null);
			}
		}
	}
	
	@ResponseBody
	@ExceptionHandler(BadAPIResponseException.class)
	public ResponseEntity<String> handleExceptionScan(BadAPIResponseException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
