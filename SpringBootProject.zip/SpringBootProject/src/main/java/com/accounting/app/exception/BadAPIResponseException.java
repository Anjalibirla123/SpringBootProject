package com.accounting.app.exception;

import org.json.JSONException;

import com.accounting.app.enums.ErrorConstants;

public class BadAPIResponseException  extends RuntimeException {

	private static final long serialVersionUID = 6802713204755223111L;
	
	public BadAPIResponseException(ErrorConstants message, Exception e) throws JSONException  {
		
		super(ErrorConstants.getAsJson(message),e);
	}
}
