package com.accounting.app.common;

public class Constants {
	
	private Constants() {
	}
	
	public static final String ERROR_DESC = "errorDesc";
	public static final String ERROR_CODE = "errorCode";
	public static final String RESPONSE_FAIL = "fail";
	public static final String SUCCESS_RESPONSE = "Success";
	

}
