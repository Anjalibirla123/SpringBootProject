package com.accounting.app.service;

import java.util.Optional;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.accounting.app.common.Constants;
import com.accounting.app.dto.ResponseDto;
import com.accounting.app.entity.User;
import com.accounting.app.repository.UserRepository;
import com.accounting.app.enums.ErrorConstants;
import com.accounting.app.exception.BadAPIResponseException;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	public ResponseDto signupUser(User user) {
		ResponseDto response = new ResponseDto();
		userRepo.save(user);
		response.setResponseText(Constants.SUCCESS_RESPONSE);
		return response;
	}

	public ResponseDto editUser(Long userId, User userDto) {
		Optional<User> user = userRepo.findById(userId);

		if (user.isPresent()) {
			User user1 = User.builder().withName(userDto.getName()).withPhoneNumber(userDto.getPhoneNumber())
					.withPolicyNumber(userDto.getPolicyNumber()).withRequirements(userDto.getRequirements())
					.withDateOfBirth(userDto.getDateOfBirth()).withEmailId(userDto.getEmailId())
					.withUserId(userDto.getUserId()).withGender(userDto.getGender())
					.withMaritalStatus(userDto.getMaritalStatus()).build();
			user1.setCreatedDate(user.get().getCreatedDate());
			if (null == userDto.getPassword())
				user1.setPassword(user.get().getPassword());
			else
				user1.setPassword(bcryptEncoder.encode(userDto.getPassword()));

			userRepo.save(user1);
		}

		return ResponseDto.builder().withResponseText(Constants.SUCCESS_RESPONSE).build();
	}

	public ResponseDto deleteByUserId(Long userId) throws BadAPIResponseException, JSONException
	{
		Optional<User> userObj = userRepo.findById(userId);
		if (!userObj.isPresent()) {
			throw new BadAPIResponseException(ErrorConstants.NO_USER_EXIST, null);
		}
		
		else
		{
			userRepo.delete(userObj.get());
		}
		
		return ResponseDto.builder().withResponseText(Constants.SUCCESS_RESPONSE).build();
		
	}
}
