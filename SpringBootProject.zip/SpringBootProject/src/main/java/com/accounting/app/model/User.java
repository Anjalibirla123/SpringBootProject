package com.accounting.app.model;

public class User {

}
