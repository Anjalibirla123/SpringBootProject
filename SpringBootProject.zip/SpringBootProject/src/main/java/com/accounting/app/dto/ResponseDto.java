package com.accounting.app.dto;

import javax.annotation.Generated;


public class ResponseDto {

	private String responseText;

	@Generated("SparkTools")
	protected ResponseDto(Builder builder) {
		this.responseText = builder.responseText;
	}

	public ResponseDto() {
		super();
	}

	public void setResponseText(String responseText) {
		this.responseText = responseText;
	}

	public ResponseDto(String responseText) {
		this.responseText = responseText;
	}

	@Override
	public String toString() {
		return "IBaseResponseDto [responseText=" + responseText + "]";
	}

	/**
	 * Creates builder to build {@link ProjectsDto}.
	 * 
	 * @return created builder
	 */
	@Generated("SparkTools")
	public static Builder builder() {
		return new Builder();
	}

	public String getResponseText() {
		return responseText;
	}

	/**
	 * Builder to build {@link ProjectsDto}.
	 */
	@Generated("SparkTools")
	public static class Builder {

		private String responseText;

		protected Builder() {
		}

		public Builder withResponseText(String responseText) {
			this.responseText = responseText;
			return this;
		}

		public ResponseDto build() {
			return new ResponseDto(this);
		}
	}

}
